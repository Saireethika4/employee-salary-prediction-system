@echo off
echo =========================================
echo Starting PaySight AI Platform...
echo =========================================

:: Install requirements just in case
pip install -r requirements.txt

:: Start the Python backend using uvicorn correctly
echo Starting the AI Engine...
start cmd /k "python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload"

:: Give the server a few seconds to start before opening the browser
timeout /t 5 /nobreak >nul

:: Open the browser to the application
echo Accessing Localhost...
start http://127.0.0.1:8000/

echo Project is now running! Keep the backend window open.
pause
