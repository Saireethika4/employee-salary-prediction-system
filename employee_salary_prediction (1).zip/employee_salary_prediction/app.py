import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from src.predict import predict_salary
from src.train import train_model

# ---------------- PAGE CONFIG ----------------
st.set_page_config(
    page_title="PaySight AI",
    layout="wide"
)

# ---------------- PAYSiGHT NEON STYLE ----------------
st.markdown("""
<style>

body {
    background-color:#06080f;
}

.main {
    background:linear-gradient(135deg,#05070d,#0b0f19);
}

h1,h2,h3 {
    color:#00ffe7;
    text-shadow:0 0 12px #00ffe7;
}

[data-testid="stSidebar"] {
    background-color:#05070d;
    border-right:1px solid #00ffe7;
}

.card {
    background:rgba(0,255,231,0.05);
    padding:20px;
    border-radius:14px;
    box-shadow:0 0 20px rgba(0,255,231,0.3);
    text-align:center;
}

.glowText {
    font-size:26px;
    color:#00ffe7;
    text-shadow:0 0 18px #00ffe7;
}

.resultBox {
    background:black;
    padding:35px;
    border-radius:14px;
    box-shadow:0 0 30px #00ffe7;
    animation: glow 1.6s infinite alternate;
    text-align:center;
    font-size:32px;
    color:#00ffe7;
}

@keyframes glow {
  from { box-shadow:0 0 12px #00ffe7;}
  to { box-shadow:0 0 35px #00ffe7;}
}

</style>
""", unsafe_allow_html=True)

# ---------------- TRAIN MODEL ----------------
train_model()

# ---------------- SIDEBAR ----------------
st.sidebar.title("⚡ PaySight AI")

st.sidebar.caption("Predictive Compensation Intelligence")

page = st.sidebar.radio(
    "Navigation",
    ["Dashboard", "Salary Prediction", "Regression Analytics"]
)

# =========================================================
# 📊 DASHBOARD
# =========================================================
if page == "Dashboard":

    st.title("⚡ PaySight AI — Compensation Intelligence Platform")
    st.caption("AI-Driven Data Engineering • Predictive Salary Analytics")

    df = pd.read_csv("data/salary_data.csv")

    col1,col2,col3 = st.columns(3)

    with col1:
        st.markdown(
            f"<div class='card glowText'>Total Records<br>{len(df)}</div>",
            unsafe_allow_html=True)

    with col2:
        st.markdown(
            f"<div class='card glowText'>Avg Salary<br>₹ {int(df['Salary'].mean())}</div>",
            unsafe_allow_html=True)

    with col3:
        st.markdown(
            f"<div class='card glowText'>Max Salary<br>₹ {int(df['Salary'].max())}</div>",
            unsafe_allow_html=True)

    st.markdown("---")

    st.subheader("🤖 PaySight AI Insight")

    st.info(
        "PaySight AI analyzes experience, education, and job roles to estimate compensation trends. "
        "Higher experience and advanced education levels show strong influence on predicted salary ranges."
    )

# =========================================================
# 💰 SALARY PREDICTION
# =========================================================
elif page == "Salary Prediction":

    st.title("💰 PaySight Prediction Engine")
    st.caption("Real-time AI Salary Estimation")

    c1,c2 = st.columns([1,1])

    with c1:

        st.markdown("<div class='card'>",unsafe_allow_html=True)

        age = st.number_input("Age",20,60,28)
        gender = st.selectbox("Gender",["Male","Female"])
        education = st.selectbox("Education",["Bachelors","Masters","PhD"])

        job = st.selectbox("Job Title",[
            "Software Engineer","Data Scientist","Web Developer","AI Researcher",
            "Intern","Project Manager","Architect","QA Engineer","DevOps Engineer",
            "UI Designer","Cloud Engineer","Backend Developer","Frontend Developer",
            "Product Manager","Security Architect","Support Engineer","HR Manager",
            "System Admin","Data Analyst"
        ])

        exp = st.number_input("Experience",0,25,3)

        st.markdown("</div>",unsafe_allow_html=True)

    gender_map = {"Female":0,"Male":1}
    edu_map = {"Bachelors":0,"Masters":1,"PhD":2}

    job_list = [
        "AI Researcher","Architect","Backend Developer","Cloud Engineer",
        "Data Analyst","Data Scientist","DevOps Engineer","Frontend Developer",
        "HR Manager","Intern","Product Manager","Project Manager","QA Engineer",
        "Security Architect","Software Engineer","Support Engineer","System Admin",
        "UI Designer","Web Developer"
    ]

    job_map = {j:i for i,j in enumerate(job_list)}

    with c2:

        st.subheader("🤖 AI Prediction Output")

        if st.button("⚡ Predict Salary"):

            sample = {
                "Age":age,
                "Gender":gender_map[gender],
                "Education":edu_map[education],
                "JobTitle":job_map[job],
                "Experience":exp
            }

            result = predict_salary(sample)

            st.markdown(
                f"<div class='resultBox'>₹ {result}</div>",
                unsafe_allow_html=True
            )

# =========================================================
# 📈 REGRESSION ANALYTICS
# =========================================================
elif page == "Regression Analytics":

    st.title("📈 PaySight AI Regression Analytics")

    df = pd.read_csv("data/salary_data.csv")

    st.subheader("Experience vs Salary")

    fig = plt.figure()
    plt.scatter(df["Experience"], df["Salary"])
    plt.xlabel("Experience")
    plt.ylabel("Salary")
    st.pyplot(fig)

    st.subheader("Age vs Salary")

    fig2 = plt.figure()
    plt.scatter(df["Age"], df["Salary"])
    plt.xlabel("Age")
    plt.ylabel("Salary")
    st.pyplot(fig2)

    st.success(
        "AI Insight: The regression patterns indicate a strong upward trend between experience and salary, "
        "supporting linear modeling assumptions."
    )