from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import pandas as pd
from src.predict import predict_salary
from src.train import train_model
from typing import Dict, Any
import os

app = FastAPI(title="PaySight AI API")

# Ensure model is trained at startup if not exists
if not os.path.exists("models/salary_model.pkl"):
    train_model()

class PredictionRequest(BaseModel):
    Age: int
    Gender: str
    Education: str
    JobTitle: str
    Experience: int

class LoginRequest(BaseModel):
    username: str
    password: str

class EmployeeRecord(BaseModel):
    EmpID: str
    Name: str
    Age: int
    Gender: str
    Education: str
    JobTitle: str
    Experience: int
    Salary: int

@app.post("/login")
async def login(req: LoginRequest):
    if req.username == "bsaiyashwant" and req.password == "bsaiyashwant":
        return {"status": "success", "message": "Authenticated"}
    else:
        raise HTTPException(status_code=401, detail="Invalid username or password")

@app.get("/", response_class=HTMLResponse)
async def read_index():
    with open("index.html", "r", encoding="utf-8") as f:
        return f.read()

@app.post("/predict")
async def predict(req: PredictionRequest):
    # Mapping
    gender_map = {"Female":0, "Male":1}
    edu_map = {"Bachelors":0, "Masters":1, "PhD":2}
    job_list = [
        "AI Researcher","Architect","Backend Developer","Cloud Engineer",
        "Data Analyst","Data Scientist","DevOps Engineer","Frontend Developer",
        "HR Manager","Intern","Product Manager","Project Manager","QA Engineer",
        "Security Architect","Software Engineer","Support Engineer","System Admin",
        "UI Designer","Web Developer"
    ]
    job_map = {j:i for i,j in enumerate(job_list)}
    
    sample = {
        "Age": req.Age,
        "Gender": gender_map.get(req.Gender, 0),
        "Education": edu_map.get(req.Education, 0),
        "JobTitle": job_map.get(req.JobTitle, 0),
        "Experience": req.Experience
    }
    result = predict_salary(sample)
    return {"predicted_salary": result}

@app.get("/employees")
async def get_employees():
    df = pd.read_csv("data/salary_data.csv")
    return df.to_dict(orient="records")

@app.post("/employees")
async def create_employee(emp: EmployeeRecord):
    df = pd.read_csv("data/salary_data.csv")
    if emp.EmpID in df['EmpID'].values:
        raise HTTPException(status_code=400, detail="Employee ID already exists")
    
    new_row = pd.DataFrame([emp.dict()])
    df = pd.concat([df, new_row], ignore_index=True)
    df.to_csv("data/salary_data.csv", index=False)
    
    # Retrain model with new data in background
    train_model()
    return {"status": "success", "message": "Employee created"}

@app.put("/employees/{emp_id}")
async def update_employee(emp_id: str, emp: EmployeeRecord):
    df = pd.read_csv("data/salary_data.csv")
    if emp_id not in df['EmpID'].values:
        raise HTTPException(status_code=404, detail="Employee not found")
        
    df = df[df['EmpID'] != emp_id]
    new_row = pd.DataFrame([emp.dict()])
    df = pd.concat([df, new_row], ignore_index=True)
    df.to_csv("data/salary_data.csv", index=False)
    
    train_model()
    return {"status": "success", "message": "Employee updated"}

@app.delete("/employees/{emp_id}")
async def delete_employee(emp_id: str):
    df = pd.read_csv("data/salary_data.csv")
    if emp_id not in df['EmpID'].values:
        raise HTTPException(status_code=404, detail="Employee not found")
        
    df = df[df['EmpID'] != emp_id]
    df.to_csv("data/salary_data.csv", index=False)
    
    train_model()
    return {"status": "success", "message": "Employee deleted"}

@app.get("/export")
async def export_data():
    return FileResponse("data/salary_data.csv", media_type="text/csv", filename="PaySight_Database_Export.csv")

@app.get("/kpi")
async def get_kpis() -> Dict[str, Any]:
    df = pd.read_csv("data/salary_data.csv")
    total_employees = len(df)
    avg_salary = int(df['Salary'].mean()) if not df.empty else 0
    max_salary = int(df['Salary'].max()) if not df.empty else 0
    
    return {
        "Total Employees": total_employees,
        "Average Salary": f"₹{avg_salary:,}",
        "Highest Salary": f"₹{max_salary:,}"
    }

@app.get("/analytics")
async def analytics():
    df = pd.read_csv("data/salary_data.csv")
    agg = df.groupby("Experience")["Salary"].mean().reset_index()
    # Ensure it's sorted by experience
    agg = agg.sort_values(by="Experience")
    return {
        "labels": agg["Experience"].tolist(),
        "data": agg["Salary"].tolist()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
